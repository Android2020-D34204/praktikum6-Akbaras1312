package id.ac.id.telkomuniversity.tass.praktikActivity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button pindah;
    EditText tulisan;

    private String KEY_NAME = "NAMA";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pindah = (Button)findViewById(R.id.button);
        tulisan = (EditText)findViewById(R.id.Etext);

        pindah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (tulisan.getText().toString().length()==0){
                    tulisan.setError("input tidak boleh kosong");
                }else if (tulisan != null){
                    Alertdialog();
                }
            }
        });
    }

    public void Alertdialog(){
        AlertDialog.Builder a = new AlertDialog.Builder(this);

        a.setTitle("Yakin ingin pindah ?");

        a.setMessage("Klik ya untuk pindah").setIcon(R.mipmap.ic_launcher).setCancelable(false).setPositiveButton("Ya", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                String nama = tulisan.getText().toString();
                    Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                    intent.putExtra(KEY_NAME, nama);
                    startActivity(intent);
                Toast.makeText(MainActivity.this, "Berhasil Pindah Ke Activy Kedua", Toast.LENGTH_SHORT).show();
            }
        }).setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });

        AlertDialog alertDialog = a.create();

        alertDialog.show();
    }
}