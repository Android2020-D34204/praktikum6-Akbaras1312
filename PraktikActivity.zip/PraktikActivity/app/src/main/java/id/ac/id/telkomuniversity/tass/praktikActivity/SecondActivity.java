package id.ac.id.telkomuniversity.tass.praktikActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    TextView coba;

    private String nama;
    private String KEY_NAME = "NAMA";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        coba = (TextView)findViewById(R.id.Tv);

        Bundle a = getIntent().getExtras();
        nama = a.getString(KEY_NAME);
        coba.setText(nama);
    }
}